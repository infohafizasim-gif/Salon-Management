# Elegance Salon - Management System
**Aptech eProject (PHP + MySQL)**

## Theme
- **Sage Green** `#667C68` — Primary
- **Warm Cream** `#F7F3EA` — Background
- **Champagne Gold** `#C9A45C` — Accents & Buttons
- **Deep Charcoal** `#252723` — Text

## Features Implemented
### Public Website
- Home page (Hero, Services, Testimonials, CTA)
- About Us
- Services listing
- Book Appointment (with client auto-create)
- Contact Us
- Feedback form

### Authentication
- Login (Admin / Receptionist / Stylist roles)
- Session-based access control
- Logout

### Admin Panel
- Dashboard with KPIs
- Appointments management (Confirm / Complete / Cancel)
- Clients list
- Inventory with Low Stock alerts
- Sidebar navigation

## Setup Instructions

1. **Create Database**
   ```bash
   mysql -u root -p < database.sql
   ```
   Or import `database.sql` via phpMyAdmin.

2. **Configure Database**
   Edit `config/database.php` if needed:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   define('DB_NAME', 'elegance_salon');
   ```

3. **Run the Project**
   - Place folder in `htdocs` / `www` (XAMPP / WAMP / Laragon)
   - Open: `http://localhost/elegance-salon/`

4. **Default Login**
   - Email: `admin@elegancesalon.com`
   - Password: `admin123`

## Folder Structure
```
elegance-salon/
├── admin/              # Admin panel
│   ├── includes/
│   ├── dashboard.php
│   ├── appointments.php
│   ├── clients.php
│   └── inventory.php
├── assets/
│   ├── css/style.css   # Full theme
│   └── js/main.js
├── config/
│   └── database.php
├── includes/
│   ├── header.php
│   └── footer.php
├── database.sql
├── index.php
├── login.php
├── book.php
├── services.php
├── about.php
├── contact.php
├── feedback.php
└── logout.php
```

## Tech Stack
- PHP 7.4+ / 8.x
- MySQL / MariaDB
- Bootstrap 5
- Font Awesome 6
- Google Fonts (Playfair Display + Poppins)

## Notes for Aptech Submission
- This is a complete working foundation.
- You can further expand: Staff CRUD, Payments, Reports, Calendar, Notifications, etc.
- Keep the same design language for consistency.
- Add more sample data as needed.

**Developed for Aptech eProject – Salon Management System**
