<?php
$pageTitle = "Home";
$activePage = "home";
require_once 'includes/header.php';
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="hero-content">
                    <p class="text-gold mb-2" style="letter-spacing: 3px; font-size: 0.9rem;">WELCOME TO ELEGANCE SALON</p>
                    <h1>Book Your Moment<br>of Luxury</h1>
                    <p class="subtitle">Experience premium salon & spa services in an atmosphere designed for beauty, relaxation, and confidence.</p>
                    <div class="d-flex gap-3 flex-wrap">
                        <a href="book.php" class="btn btn-gold">
                            <i class="fas fa-calendar-check"></i> Book Appointment
                        </a>
                        <a href="services.php" class="btn btn-outline-gold">
                            View Services
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 d-none d-lg-block text-center">
                <div class="p-4">
                    <i class="fas fa-spa" style="font-size: 12rem; color: var(--gold); opacity: 0.25;"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Featured Services -->
<section class="py-5">
    <div class="container">
        <div class="section-title">
            <h2>Our Signature Services</h2>
            <div class="divider"></div>
            <p>Premium treatments crafted for your beauty and wellness</p>
        </div>
        <div class="row g-4">
            <?php
            $services = [
                ['icon' => 'fa-cut', 'title' => 'Hair Styling & Color', 'desc' => 'Precision cuts, balayage, highlights and custom color.', 'price' => 'From $85'],
                ['icon' => 'fa-spa', 'title' => 'Facial & Skin Therapy', 'desc' => 'Rejuvenating facials for radiant, healthy, glowing skin.', 'price' => 'From $120'],
                ['icon' => 'fa-hand-sparkles', 'title' => 'Nails & Beauty', 'desc' => 'Manicures, pedicures, gel and nail art that inspire.', 'price' => 'From $70'],
                ['icon' => 'fa-hot-tub-person', 'title' => 'Massage & Wellness', 'desc' => 'Relaxing massages to restore balance and well-being.', 'price' => 'From $130'],
            ];
            foreach ($services as $s):
            ?>
            <div class="col-md-6 col-lg-3">
                <div class="service-card text-center p-4 h-100">
                    <div class="mb-3">
                        <i class="fas <?php echo $s['icon']; ?> fa-2x text-gold"></i>
                    </div>
                    <h5><?php echo $s['title']; ?></h5>
                    <p class="text-muted small"><?php echo $s['desc']; ?></p>
                    <p class="price mb-3"><?php echo $s['price']; ?></p>
                    <a href="book.php" class="btn btn-outline-gold btn-sm">Book Now</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Why Choose Us -->
<section class="py-5" style="background: var(--cream-dark);">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <h2 class="mb-3">Why Choose Elegance?</h2>
                <div class="divider mb-4" style="margin-left:0;"></div>
                <div class="d-flex gap-3 mb-4">
                    <div class="flex-shrink-0">
                        <div class="kpi-icon"><i class="fas fa-user-check"></i></div>
                    </div>
                    <div>
                        <h5>Expert Stylists</h5>
                        <p class="text-muted mb-0">Highly trained professionals with years of experience.</p>
                    </div>
                </div>
                <div class="d-flex gap-3 mb-4">
                    <div class="flex-shrink-0">
                        <div class="kpi-icon"><i class="fas fa-leaf"></i></div>
                    </div>
                    <div>
                        <h5>Premium Products</h5>
                        <p class="text-muted mb-0">We use only the finest quality products for your care.</p>
                    </div>
                </div>
                <div class="d-flex gap-3">
                    <div class="flex-shrink-0">
                        <div class="kpi-icon"><i class="fas fa-heart"></i></div>
                    </div>
                    <div>
                        <h5>Personalized Experience</h5>
                        <p class="text-muted mb-0">Every treatment tailored to your unique needs.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 text-center">
                <div class="card-elegant p-5">
                    <i class="fas fa-quote-left fa-2x text-gold mb-3"></i>
                    <p class="fs-5 fst-italic">"Elegance Salon is my sanctuary. Every visit feels luxurious, personalized, and truly relaxing."</p>
                    <p class="text-gold mb-0 fw-medium">— Olivia M.</p>
                    <small class="text-muted">Verified Client</small>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="py-5">
    <div class="container">
        <div class="card-elegant text-center p-5" style="background: linear-gradient(135deg, var(--sage), var(--sage-dark)); color: white;">
            <h2 class="text-white mb-3">Ready for Your Transformation?</h2>
            <p class="mb-4 opacity-75">Book your appointment today and experience the Elegance difference.</p>
            <a href="book.php" class="btn btn-gold btn-lg">
                <i class="fas fa-calendar-plus"></i> Book Your Appointment
            </a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
