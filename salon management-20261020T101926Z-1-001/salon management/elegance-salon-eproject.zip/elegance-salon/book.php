<?php
$pageTitle = "Book Appointment";
$activePage = "book";
require_once 'config/database.php';
require_once 'includes/header.php';

$success = '';
$error = '';

// Fetch services
$services = $pdo->query("SELECT * FROM services WHERE status = 'active' ORDER BY category, name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $service_id = (int)($_POST['service_id'] ?? 0);
    $date = $_POST['appointment_date'] ?? '';
    $time = $_POST['appointment_time'] ?? '';
    $notes = trim($_POST['notes'] ?? '');

    if (empty($name) || empty($phone) || empty($service_id) || empty($date) || empty($time)) {
        $error = 'Please fill all required fields.';
    } else {
        try {
            // Check if client exists, else create
            $stmt = $pdo->prepare("SELECT id FROM clients WHERE phone = ? OR email = ?");
            $stmt->execute([$phone, $email]);
            $client = $stmt->fetch();

            if ($client) {
                $client_id = $client['id'];
            } else {
                $stmt = $pdo->prepare("INSERT INTO clients (name, email, phone) VALUES (?, ?, ?)");
                $stmt->execute([$name, $email, $phone]);
                $client_id = $pdo->lastInsertId();
            }

            // Create appointment
            $stmt = $pdo->prepare("INSERT INTO appointments (client_id, service_id, appointment_date, appointment_time, status, notes) VALUES (?, ?, ?, ?, 'pending', ?)");
            $stmt->execute([$client_id, $service_id, $date, $time, $notes]);

            $success = 'Appointment booked successfully! We will confirm shortly.';
        } catch (Exception $e) {
            $error = 'Something went wrong. Please try again.';
        }
    }
}
?>

<section class="py-5">
    <div class="container">
        <div class="section-title">
            <h2>Book Appointment</h2>
            <div class="divider"></div>
            <p>Luxury Care. Personalized for You.</p>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success text-center"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger text-center"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="card-elegant">
                    <form method="POST" action="">
                        <div class="row g-4">
                            <!-- Service Selection -->
                            <div class="col-12">
                                <h5 class="mb-3"><span class="badge bg-sage me-2">1</span> Select Service</h5>
                                <div class="row g-3">
                                    <?php foreach ($services as $service): ?>
                                    <div class="col-md-6 col-lg-4">
                                        <label class="w-100">
                                            <input type="radio" name="service_id" value="<?php echo $service['id']; ?>" class="d-none service-radio" required>
                                            <div class="card-elegant p-3 service-option" style="cursor:pointer; border: 2px solid transparent;">
                                                <h6 class="mb-1"><?php echo htmlspecialchars($service['name']); ?></h6>
                                                <small class="text-muted"><?php echo $service['duration']; ?> min</small>
                                                <p class="price mb-0 mt-1">$<?php echo number_format($service['price'], 2); ?></p>
                                            </div>
                                        </label>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <!-- Date & Time -->
                            <div class="col-md-6">
                                <h5 class="mb-3"><span class="badge bg-sage me-2">2</span> Select Date</h5>
                                <input type="date" name="appointment_date" class="form-control form-control-elegant" required min="<?php echo date('Y-m-d'); ?>">
                            </div>
                            <div class="col-md-6">
                                <h5 class="mb-3"><span class="badge bg-sage me-2">3</span> Select Time</h5>
                                <select name="appointment_time" class="form-control form-control-elegant" required>
                                    <option value="">Choose time</option>
                                    <option value="10:00">10:00 AM</option>
                                    <option value="11:00">11:00 AM</option>
                                    <option value="12:00">12:00 PM</option>
                                    <option value="13:00">1:00 PM</option>
                                    <option value="14:00">2:00 PM</option>
                                    <option value="15:00">3:00 PM</option>
                                    <option value="16:00">4:00 PM</option>
                                    <option value="17:00">5:00 PM</option>
                                    <option value="18:00">6:00 PM</option>
                                    <option value="19:00">7:00 PM</option>
                                </select>
                            </div>

                            <!-- Client Info -->
                            <div class="col-12">
                                <h5 class="mb-3"><span class="badge bg-sage me-2">4</span> Your Information</h5>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label-elegant">Full Name *</label>
                                <input type="text" name="name" class="form-control form-control-elegant" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label-elegant">Email</label>
                                <input type="email" name="email" class="form-control form-control-elegant">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label-elegant">Phone *</label>
                                <input type="tel" name="phone" class="form-control form-control-elegant" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label-elegant">Notes (optional)</label>
                                <textarea name="notes" class="form-control form-control-elegant" rows="2" placeholder="Any special requests..."></textarea>
                            </div>

                            <div class="col-12 text-center mt-3">
                                <button type="submit" class="btn btn-gold btn-lg px-5">
                                    <i class="fas fa-check-circle"></i> Confirm Booking
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
document.querySelectorAll('.service-radio').forEach(radio => {
    radio.addEventListener('change', function() {
        document.querySelectorAll('.service-option').forEach(el => {
            el.style.borderColor = 'transparent';
            el.style.background = 'var(--white)';
        });
        if (this.checked) {
            this.nextElementSibling.style.borderColor = 'var(--gold)';
            this.nextElementSibling.style.background = 'rgba(201, 164, 92, 0.08)';
        }
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>
