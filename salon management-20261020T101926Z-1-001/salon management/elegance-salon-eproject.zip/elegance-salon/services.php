<?php
$pageTitle = "Services";
$activePage = "services";
require_once 'config/database.php';
require_once 'includes/header.php';

$services = $pdo->query("SELECT * FROM services WHERE status = 'active' ORDER BY category, name")->fetchAll();
$categories = [];
foreach ($services as $s) {
    $categories[$s['category']][] = $s;
}
?>

<section class="py-5">
    <div class="container">
        <div class="section-title">
            <h2>Our Services</h2>
            <div class="divider"></div>
            <p>Premium treatments designed for your beauty and wellness</p>
        </div>

        <?php foreach ($categories as $cat => $items): ?>
        <h4 class="mb-4 text-sage"><?php echo htmlspecialchars($cat); ?></h4>
        <div class="row g-4 mb-5">
            <?php foreach ($items as $service): ?>
            <div class="col-md-6 col-lg-4">
                <div class="service-card h-100">
                    <div class="card-body">
                        <h5><?php echo htmlspecialchars($service['name']); ?></h5>
                        <p class="text-muted small"><?php echo htmlspecialchars($service['description']); ?></p>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <span class="text-muted"><i class="far fa-clock me-1"></i> <?php echo $service['duration']; ?> min</span>
                            <span class="price">$<?php echo number_format($service['price'], 2); ?></span>
                        </div>
                        <a href="book.php" class="btn btn-outline-gold btn-sm w-100 mt-3">Book Now</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
