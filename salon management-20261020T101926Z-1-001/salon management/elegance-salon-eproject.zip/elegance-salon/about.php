<?php
$pageTitle = "About Us";
$activePage = "about";
require_once 'includes/header.php';
?>

<section class="py-5">
    <div class="container">
        <div class="section-title">
            <h2>About Elegance Salon</h2>
            <div class="divider"></div>
        </div>
        <div class="row g-5 align-items-center">
            <div class="col-lg-6">
                <h3 class="mb-3">Our Story</h3>
                <p>Elegance Salon was founded with a simple vision — to create a sanctuary where beauty meets tranquility. We believe every client deserves personalized care in a luxurious, calming environment.</p>
                <p>Our team of expert stylists, therapists, and beauty professionals are dedicated to delivering exceptional results using premium products and the latest techniques.</p>
                <div class="row g-3 mt-4">
                    <div class="col-6">
                        <div class="card-elegant text-center p-3">
                            <h3 class="text-gold mb-0">10+</h3>
                            <small class="text-muted">Years Experience</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card-elegant text-center p-3">
                            <h3 class="text-gold mb-0">5k+</h3>
                            <small class="text-muted">Happy Clients</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card-elegant p-5 text-center">
                    <i class="fas fa-spa fa-4x text-gold mb-4"></i>
                    <h4>Our Values</h4>
                    <ul class="list-unstyled mt-3 text-start">
                        <li class="mb-2"><i class="fas fa-check text-gold me-2"></i> Excellence in every detail</li>
                        <li class="mb-2"><i class="fas fa-check text-gold me-2"></i> Client-centered care</li>
                        <li class="mb-2"><i class="fas fa-check text-gold me-2"></i> Sustainable beauty practices</li>
                        <li class="mb-2"><i class="fas fa-check text-gold me-2"></i> Continuous learning & innovation</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
