// Elegance Salon - Main JS

document.addEventListener('DOMContentLoaded', function() {
    // Simple fade-in animation for cards
    const cards = document.querySelectorAll('.card-elegant, .service-card, .kpi-card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(15px)';
        setTimeout(() => {
            card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 80);
    });
});
