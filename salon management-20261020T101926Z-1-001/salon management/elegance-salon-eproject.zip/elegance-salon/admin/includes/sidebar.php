<div class="sidebar">
    <div class="sidebar-brand">
        <h4><i class="fas fa-spa me-2"></i>ELEGANCE</h4>
        <small>LUXURY & SPA</small>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php" class="<?php echo ($adminPage ?? '') === 'dashboard' ? 'active' : ''; ?>"><i class="fas fa-home"></i> Dashboard</a></li>
        <li><a href="appointments.php" class="<?php echo ($adminPage ?? '') === 'appointments' ? 'active' : ''; ?>"><i class="fas fa-calendar-check"></i> Appointments</a></li>
        <li><a href="clients.php" class="<?php echo ($adminPage ?? '') === 'clients' ? 'active' : ''; ?>"><i class="fas fa-users"></i> Clients</a></li>
        <li><a href="services.php" class="<?php echo ($adminPage ?? '') === 'services' ? 'active' : ''; ?>"><i class="fas fa-spa"></i> Services</a></li>
        <li><a href="inventory.php" class="<?php echo ($adminPage ?? '') === 'inventory' ? 'active' : ''; ?>"><i class="fas fa-boxes"></i> Inventory</a></li>
        <li><a href="staff.php" class="<?php echo ($adminPage ?? '') === 'staff' ? 'active' : ''; ?>"><i class="fas fa-user-tie"></i> Staff</a></li>
        <li><a href="payments.php" class="<?php echo ($adminPage ?? '') === 'payments' ? 'active' : ''; ?>"><i class="fas fa-credit-card"></i> Payments</a></li>
        <li><a href="reports.php" class="<?php echo ($adminPage ?? '') === 'reports' ? 'active' : ''; ?>"><i class="fas fa-chart-bar"></i> Reports</a></li>
        <li><a href="feedback.php" class="<?php echo ($adminPage ?? '') === 'feedback' ? 'active' : ''; ?>"><i class="fas fa-comments"></i> Feedback</a></li>
        <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
    <div class="px-3 mt-4">
        <div class="p-3 rounded" style="background: rgba(255,255,255,0.1); font-size: 0.8rem;">
            <i class="fas fa-quote-left me-1"></i>
            “Beauty is not just what you see, it's how you make people feel.”
        </div>
    </div>
</div>
