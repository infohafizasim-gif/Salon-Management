<?php
require_once 'includes/auth_check.php';
require_once '../config/database.php';
$adminPage = 'services';
$pageTitle = 'Services';
$services = $pdo->query("SELECT * FROM services ORDER BY category, name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> | Elegance Salon</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="admin-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <div class="topbar"><h5 class="mb-0">Services</h5></div>
        <div class="content-area">
            <div class="card-elegant">
                <table class="table table-elegant mb-0">
                    <thead><tr><th>#</th><th>Name</th><th>Category</th><th>Duration</th><th>Price</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php foreach ($services as $i => $s): ?>
                        <tr>
                            <td><?php echo $i+1; ?></td>
                            <td><?php echo htmlspecialchars($s['name']); ?></td>
                            <td><?php echo htmlspecialchars($s['category']); ?></td>
                            <td><?php echo $s['duration']; ?> min</td>
                            <td>$<?php echo number_format($s['price'],2); ?></td>
                            <td><span class="badge-status badge-<?php echo $s['status']==='active'?'confirmed':'cancelled'; ?>"><?php echo ucfirst($s['status']); ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
