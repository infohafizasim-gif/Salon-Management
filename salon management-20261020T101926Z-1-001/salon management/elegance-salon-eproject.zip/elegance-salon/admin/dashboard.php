<?php
require_once 'includes/auth_check.php';
require_once '../config/database.php';

$adminPage = 'dashboard';
$pageTitle = 'Dashboard';

// Stats
$totalAppointments = $pdo->query("SELECT COUNT(*) FROM appointments")->fetchColumn();
$todayBookings = $pdo->query("SELECT COUNT(*) FROM appointments WHERE appointment_date = CURDATE()")->fetchColumn();
$totalClients = $pdo->query("SELECT COUNT(*) FROM clients")->fetchColumn();
$lowStock = $pdo->query("SELECT COUNT(*) FROM inventory WHERE quantity <= low_stock_threshold")->fetchColumn();
$revenue = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE payment_status = 'paid'")->fetchColumn();

// Upcoming appointments
$upcoming = $pdo->query("
    SELECT a.*, c.name as client_name, s.name as service_name 
    FROM appointments a
    JOIN clients c ON a.client_id = c.id
    JOIN services s ON a.service_id = s.id
    WHERE a.appointment_date >= CURDATE() AND a.status IN ('pending','confirmed')
    ORDER BY a.appointment_date, a.appointment_time
    LIMIT 8
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> | Elegance Salon</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="admin-wrapper">
    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">
        <div class="topbar">
            <div>
                <h5 class="mb-0">Dashboard</h5>
                <small class="text-muted">Welcome back, <?php echo htmlspecialchars($_SESSION['user_name']); ?></small>
            </div>
            <div class="d-flex align-items-center gap-3">
                <span class="badge bg-sage"><?php echo ucfirst($_SESSION['user_role']); ?></span>
                <a href="../logout.php" class="btn btn-sm btn-outline-gold">Logout</a>
            </div>
        </div>

        <div class="content-area">
            <!-- KPI Cards -->
            <div class="row g-4 mb-4">
                <div class="col-md-6 col-xl-3">
                    <div class="kpi-card">
                        <div class="d-flex justify-content-between">
                            <div>
                                <div class="kpi-label">Total Appointments</div>
                                <div class="kpi-value"><?php echo number_format($totalAppointments); ?></div>
                            </div>
                            <div class="kpi-icon"><i class="fas fa-calendar-alt"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="kpi-card">
                        <div class="d-flex justify-content-between">
                            <div>
                                <div class="kpi-label">Today's Bookings</div>
                                <div class="kpi-value"><?php echo $todayBookings; ?></div>
                            </div>
                            <div class="kpi-icon"><i class="fas fa-clock"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="kpi-card">
                        <div class="d-flex justify-content-between">
                            <div>
                                <div class="kpi-label">Total Clients</div>
                                <div class="kpi-value"><?php echo number_format($totalClients); ?></div>
                            </div>
                            <div class="kpi-icon"><i class="fas fa-users"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="kpi-card">
                        <div class="d-flex justify-content-between">
                            <div>
                                <div class="kpi-label">Low Stock Alerts</div>
                                <div class="kpi-value text-danger"><?php echo $lowStock; ?></div>
                            </div>
                            <div class="kpi-icon" style="background: rgba(220,53,69,0.1); color: #dc3545;"><i class="fas fa-exclamation-triangle"></i></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Upcoming Appointments -->
            <div class="card-elegant">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">Upcoming Appointments</h5>
                    <a href="appointments.php" class="btn btn-sm btn-outline-gold">View All</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-elegant mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Client</th>
                                <th>Service</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($upcoming)): ?>
                                <tr><td colspan="5" class="text-center text-muted py-4">No upcoming appointments</td></tr>
                            <?php else: ?>
                                <?php foreach ($upcoming as $row): ?>
                                <tr>
                                    <td><?php echo date('d M Y', strtotime($row['appointment_date'])); ?></td>
                                    <td><?php echo date('h:i A', strtotime($row['appointment_time'])); ?></td>
                                    <td><?php echo htmlspecialchars($row['client_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['service_name']); ?></td>
                                    <td>
                                        <span class="badge-status badge-<?php echo $row['status']; ?>">
                                            <?php echo ucfirst($row['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
