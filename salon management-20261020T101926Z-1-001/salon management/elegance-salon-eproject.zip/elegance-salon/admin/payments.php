<?php
require_once 'includes/auth_check.php';
require_once '../config/database.php';
$adminPage = 'payments';
$pageTitle = 'Payments';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> | Elegance Salon</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="admin-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <div class="topbar"><h5 class="mb-0">Payments & Invoices</h5></div>
        <div class="content-area">
            <div class="card-elegant text-center py-5">
                <i class="fas fa-credit-card fa-3x text-gold mb-3"></i>
                <h5>Payments Module</h5>
                <p class="text-muted">Expand this to record payments, generate invoices and track revenue.</p>
            </div>
        </div>
    </div>
</div>
</body>
</html>
